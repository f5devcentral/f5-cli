# F5 Cloud CLI

F5 Cloud CLI

## Quick Start

This is still a work in progress (no venv, etc.), however below are the current steps to use the cli.

```bash
pip3 install -r requirements.txt
pip3 install .
bin/f5cloudcli
```